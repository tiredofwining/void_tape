package com.voidtape.player

import android.Manifest
import android.content.ComponentName
import android.content.pm.PackageManager
import android.database.Cursor
import android.graphics.Color
import android.graphics.BitmapFactory
import android.graphics.Typeface
import android.net.Uri
import android.os.Build
import android.os.Bundle
import android.os.Handler
import android.os.Looper
import android.provider.MediaStore
import android.view.Gravity
import android.view.View
import android.widget.*
import androidx.activity.result.contract.ActivityResultContracts
import androidx.appcompat.app.AppCompatActivity
import androidx.core.content.ContextCompat
import androidx.core.view.setPadding
import androidx.media3.common.MediaItem
import androidx.media3.common.Player
import androidx.media3.session.MediaController
import androidx.media3.session.SessionToken
import com.google.common.util.concurrent.ListenableFuture

 data class Track(val id: Long, val title: String, val artist: String, val albumId: Long, val uri: Uri)

class MainActivity : AppCompatActivity() {
    private val lime = Color.rgb(168, 255, 96)
    private val bg = Color.rgb(10, 11, 10)
    private val panel = Color.rgb(24, 26, 23)
    private val muted = Color.rgb(153, 158, 148)
    private lateinit var list: LinearLayout
    private lateinit var nowTitle: TextView
    private lateinit var nowArtist: TextView
    private lateinit var playButton: TextView
    private lateinit var status: TextView
    private lateinit var cover: ImageView
    private lateinit var progress: SeekBar
    private lateinit var elapsed: TextView
    private lateinit var duration: TextView
    private var controller: MediaController? = null
    private var controllerFuture: ListenableFuture<MediaController>? = null
    private val tracks = mutableListOf<Track>()
    private val handler = Handler(Looper.getMainLooper())
    private var userSeeking = false

    private val progressUpdater = object : Runnable {
        override fun run() {
            val c = controller
            if (c != null && !userSeeking) {
                val total = c.duration.takeIf { it > 0L } ?: 0L
                val position = c.currentPosition.coerceAtLeast(0L)
                progress.max = 1000
                progress.progress = if (total > 0L) ((position.toDouble() / total) * 1000).toInt().coerceIn(0, 1000) else 0
                elapsed.text = formatTime(position)
                duration.text = formatTime(total)
            }
            handler.postDelayed(this, 500L)
        }
    }

    private val permissionLauncher = registerForActivityResult(ActivityResultContracts.RequestPermission()) {
        if (it) loadTracks() else status.text = "Нужен доступ к аудиофайлам на устройстве."
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        window.statusBarColor = bg
        window.navigationBarColor = bg
        window.decorView.systemUiVisibility = 0
        buildUi()
        connectController()
        val permission = if (Build.VERSION.SDK_INT >= 33) Manifest.permission.READ_MEDIA_AUDIO else Manifest.permission.READ_EXTERNAL_STORAGE
        if (ContextCompat.checkSelfPermission(this, permission) == PackageManager.PERMISSION_GRANTED) loadTracks()
        else permissionLauncher.launch(permission)
        handler.post(progressUpdater)
    }

    private fun buildUi() {
        val outer = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setBackgroundColor(bg)
            setPadding(dp(18), dp(10), dp(18), dp(10))
        }
        val brand = TextView(this).apply {
            text = "V O I D   T A P E     /     O F F L I N E"
            textSize = 11f
            letterSpacing = .04f
            setTextColor(lime)
            typeface = Typeface.MONOSPACE
            gravity = Gravity.CENTER_VERTICAL
        }
        outer.addView(brand, LinearLayout.LayoutParams(-1, dp(30)))

        outer.addView(TextView(this).apply {
            text = "ТВОЯ МУЗЫКА.\nБЕЗ СЕТИ."
            textSize = 29f
            setTextColor(Color.WHITE)
            typeface = Typeface.create("sans-serif-black", Typeface.BOLD)
            setLineSpacing(0f, 0.96f)
        }, LinearLayout.LayoutParams(-1, dp(88)))

        status = TextView(this).apply {
            text = "Ищу музыку на устройстве…"
            textSize = 11f
            setTextColor(muted)
            gravity = Gravity.CENTER_VERTICAL
            typeface = Typeface.MONOSPACE
        }
        outer.addView(status, LinearLayout.LayoutParams(-1, dp(30)))
        val scroll = ScrollView(this).apply { isFillViewport = false; clipToPadding = false }
        list = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL }
        scroll.addView(list)
        outer.addView(scroll, LinearLayout.LayoutParams(-1, 0, 1f))

        val playerPanel = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setBackgroundColor(panel)
            setPadding(dp(14))
        }
        val top = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL; gravity = Gravity.CENTER_VERTICAL }
        cover = ImageView(this).apply {
            scaleType = ImageView.ScaleType.CENTER_CROP
            setBackgroundColor(Color.rgb(37, 42, 33))
            setImageDrawable(null)
            contentDescription = "Обложка альбома"
        }
        val placeholder = TextView(this).apply {
            text = "VT"
            textSize = 24f
            setTextColor(lime)
            typeface = Typeface.create("sans-serif-black", Typeface.BOLD)
            gravity = Gravity.CENTER
            setBackgroundColor(Color.rgb(37, 42, 33))
        }
        val coverFrame = FrameLayout(this).apply {
            addView(cover, FrameLayout.LayoutParams(-1, -1))
            addView(placeholder, FrameLayout.LayoutParams(-1, -1))
            tag = placeholder
        }
        top.addView(coverFrame, LinearLayout.LayoutParams(dp(72), dp(72)))
        val labels = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            gravity = Gravity.CENTER_VERTICAL
            setPadding(dp(12), 0, 0, 0)
        }
        nowTitle = TextView(this).apply {
            text = "НИЧЕГО НЕ ИГРАЕТ"
            textSize = 15f
            setTextColor(Color.WHITE)
            typeface = Typeface.create("sans-serif-medium", Typeface.BOLD)
            maxLines = 2
            ellipsize = android.text.TextUtils.TruncateAt.END
        }
        nowArtist = TextView(this).apply {
            text = "Выбери трек из библиотеки"
            textSize = 12f
            setTextColor(muted)
            maxLines = 1
            ellipsize = android.text.TextUtils.TruncateAt.END
        }
        labels.addView(nowTitle)
        labels.addView(nowArtist, LinearLayout.LayoutParams(-1, dp(25)))
        top.addView(labels, LinearLayout.LayoutParams(0, -1, 1f))
        playerPanel.addView(top)

        val timeRow = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL; gravity = Gravity.CENTER_VERTICAL }
        elapsed = TextView(this).apply { text = "0:00"; textSize = 10f; setTextColor(muted); typeface = Typeface.MONOSPACE }
        duration = TextView(this).apply { text = "0:00"; textSize = 10f; setTextColor(muted); typeface = Typeface.MONOSPACE; gravity = Gravity.END }
        timeRow.addView(elapsed, LinearLayout.LayoutParams(0, dp(22), 1f))
        timeRow.addView(duration, LinearLayout.LayoutParams(0, dp(22), 1f))
        playerPanel.addView(timeRow)
        progress = SeekBar(this).apply {
            max = 1000
            progress = 0
            progressTintList = android.content.res.ColorStateList.valueOf(lime)
            thumbTintList = android.content.res.ColorStateList.valueOf(lime)
            progressBackgroundTintList = android.content.res.ColorStateList.valueOf(Color.rgb(65, 69, 61))
            setPadding(0, 0, 0, 0)
            setOnSeekBarChangeListener(object : SeekBar.OnSeekBarChangeListener {
                override fun onStartTrackingTouch(seekBar: SeekBar?) { userSeeking = true }
                override fun onProgressChanged(seekBar: SeekBar?, value: Int, fromUser: Boolean) {
                    if (fromUser) {
                        val total = controller?.duration?.takeIf { it > 0L } ?: 0L
                        elapsed.text = formatTime(total * value / 1000)
                    }
                }
                override fun onStopTrackingTouch(seekBar: SeekBar?) {
                    val c = controller
                    val total = c?.duration?.takeIf { it > 0L } ?: 0L
                    if (c != null && total > 0L) c.seekTo(total * progress.progress / 1000)
                    userSeeking = false
                }
            })
        }
        playerPanel.addView(progress, LinearLayout.LayoutParams(-1, dp(24)))

        val controls = LinearLayout(this).apply { gravity = Gravity.CENTER; orientation = LinearLayout.HORIZONTAL }
        val prev = controlButton("|◀") { controller?.seekToPreviousMediaItem() }
        playButton = controlButton("▶") { togglePlayback() }
        val next = controlButton("▶|") { controller?.seekToNextMediaItem() }
        controls.addView(prev, LinearLayout.LayoutParams(0, dp(48), 1f))
        controls.addView(playButton, LinearLayout.LayoutParams(0, dp(48), 1.25f))
        controls.addView(next, LinearLayout.LayoutParams(0, dp(48), 1f))
        playerPanel.addView(controls)
        outer.addView(playerPanel, LinearLayout.LayoutParams(-1, dp(226)))
        setContentView(outer)
    }

    private fun controlButton(label: String, action: () -> Unit): TextView = TextView(this).apply {
        text = label
        textSize = if (label == "▶" || label == "Ⅱ") 23f else 18f
        setTextColor(lime)
        gravity = Gravity.CENTER
        typeface = Typeface.create("sans-serif-medium", Typeface.BOLD)
        setBackgroundResource(android.R.drawable.btn_default)
        backgroundTintList = android.content.res.ColorStateList.valueOf(panel)
        isClickable = true
        isFocusable = true
        setOnClickListener { action() }
    }

    private fun connectController() {
        val token = SessionToken(this, ComponentName(this, PlaybackService::class.java))
        controllerFuture = MediaController.Builder(this, token).buildAsync()
        controllerFuture?.addListener({
            try {
                controller = controllerFuture?.get()
                controller?.addListener(object : Player.Listener {
                    override fun onMediaItemTransition(mediaItem: MediaItem?, reason: Int) = updateNowPlaying()
                    override fun onIsPlayingChanged(isPlaying: Boolean) { playButton.text = if (isPlaying) "Ⅱ" else "▶" }
                    override fun onPlaybackStateChanged(playbackState: Int) { updateNowPlaying() }
                })
                updateNowPlaying()
            } catch (_: Exception) { status.text = "Не удалось запустить плеер." }
        }, ContextCompat.getMainExecutor(this))
    }

    private fun loadTracks() {
        tracks.clear()
        val collection = MediaStore.Audio.Media.EXTERNAL_CONTENT_URI
        val projection = arrayOf(MediaStore.Audio.Media._ID, MediaStore.Audio.Media.TITLE, MediaStore.Audio.Media.ARTIST, MediaStore.Audio.Media.ALBUM_ID)
        val selection = "${MediaStore.Audio.Media.IS_MUSIC} != 0"
        try {
            contentResolver.query(collection, projection, selection, null, "${MediaStore.Audio.Media.TITLE} COLLATE NOCASE ASC")?.use { c: Cursor ->
                val idCol = c.getColumnIndexOrThrow(MediaStore.Audio.Media._ID)
                val titleCol = c.getColumnIndexOrThrow(MediaStore.Audio.Media.TITLE)
                val artistCol = c.getColumnIndexOrThrow(MediaStore.Audio.Media.ARTIST)
                val albumCol = c.getColumnIndexOrThrow(MediaStore.Audio.Media.ALBUM_ID)
                while (c.moveToNext()) {
                    val id = c.getLong(idCol)
                    val title = c.getString(titleCol)?.takeUnless { it.isBlank() || it.equals("<unknown>", true) } ?: "Без названия"
                    val artist = c.getString(artistCol)?.takeUnless { it.isBlank() || it.equals("<unknown>", true) } ?: "Неизвестный исполнитель"
                    val albumId = c.getLong(albumCol)
                    val uri = android.content.ContentUris.withAppendedId(collection, id)
                    tracks.add(Track(id, title, artist, albumId, uri))
                }
            }
        } catch (_: Exception) { }
        list.removeAllViews()
        status.text = if (tracks.isEmpty()) "МУЗЫКА НЕ НАЙДЕНА · ДОБАВЬ ФАЙЛЫ НА ТЕЛЕФОН" else "ЛОКАЛЬНАЯ БИБЛИОТЕКА  ·  ${tracks.size} ТРЕКОВ"
        tracks.forEachIndexed { index, track ->
            val row = LinearLayout(this).apply {
                orientation = LinearLayout.VERTICAL
                setPadding(dp(12), dp(9), dp(12), dp(8))
                setBackgroundColor(if (index % 2 == 0) panel else bg)
                isClickable = true
                isFocusable = true
                setOnClickListener { playTrack(index) }
            }
            row.addView(TextView(this).apply {
                text = track.title
                textSize = 14f
                setTextColor(Color.WHITE)
                maxLines = 1
                ellipsize = android.text.TextUtils.TruncateAt.END
            })
            row.addView(TextView(this).apply {
                text = track.artist
                textSize = 11f
                setTextColor(muted)
                maxLines = 1
                ellipsize = android.text.TextUtils.TruncateAt.END
            })
            list.addView(row, LinearLayout.LayoutParams(-1, dp(62)))
            list.addView(View(this).apply { setBackgroundColor(Color.rgb(43, 46, 40)) }, LinearLayout.LayoutParams(-1, dp(1)))
        }
        updateNowPlaying()
    }

    private fun playTrack(index: Int) {
        val c = controller ?: run { status.text = "Плеер запускается, попробуй ещё раз через секунду."; return }
        val items = tracks.map { MediaItem.fromUri(it.uri) }
        c.setMediaItems(items, index, 0L)
        c.prepare()
        c.play()
        updateNowPlaying()
    }

    private fun togglePlayback() {
        val c = controller ?: return
        if (c.isPlaying) c.pause() else {
            if (c.mediaItemCount == 0 && tracks.isNotEmpty()) playTrack(0) else c.play()
        }
        playButton.text = if (c.isPlaying) "Ⅱ" else "▶"
    }

    private fun updateNowPlaying() {
        val c = controller ?: return
        val index = c.currentMediaItemIndex
        if (index in tracks.indices) {
            val track = tracks[index]
            nowTitle.text = track.title
            nowArtist.text = track.artist
            var hasCover = false
            if (track.albumId > 0L) {
                val albumArt = Uri.parse("content://media/external/audio/albumart/${track.albumId}")
                try {
                    contentResolver.openInputStream(albumArt)?.use { stream ->
                        cover.setImageBitmap(BitmapFactory.decodeStream(stream))
                        hasCover = cover.drawable != null
                    }
                } catch (_: Exception) { }
            }
            if (!hasCover) cover.setImageDrawable(null)
            (cover.parent as? FrameLayout)?.let { frame ->
                (frame.tag as? TextView)?.visibility = if (hasCover) View.GONE else View.VISIBLE
            }
        } else {
            nowTitle.text = "НИЧЕГО НЕ ИГРАЕТ"
            nowArtist.text = "Выбери трек из библиотеки"
            cover.setImageDrawable(null)
            (cover.parent as? FrameLayout)?.let { (it.tag as? TextView)?.visibility = View.VISIBLE }
        }
        playButton.text = if (c.isPlaying) "Ⅱ" else "▶"
    }

    private fun formatTime(ms: Long): String {
        if (ms <= 0L) return "0:00"
        val totalSeconds = ms / 1000
        return "${totalSeconds / 60}:${(totalSeconds % 60).toString().padStart(2, '0')}"
    }

    private fun dp(value: Int) = (value * resources.displayMetrics.density).toInt()

    override fun onDestroy() {
        handler.removeCallbacks(progressUpdater)
        controllerFuture?.let { MediaController.releaseFuture(it) }
        super.onDestroy()
    }
}

