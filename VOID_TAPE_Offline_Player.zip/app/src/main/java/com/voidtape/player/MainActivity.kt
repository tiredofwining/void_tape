package com.voidtape.player

import android.Manifest
import android.animation.ValueAnimator
import android.content.ComponentName
import android.content.Intent
import android.content.pm.PackageManager
import android.database.Cursor
import android.graphics.BitmapFactory
import android.graphics.Canvas
import android.graphics.Color
import android.graphics.Paint
import android.graphics.Typeface
import android.graphics.drawable.ColorDrawable
import android.net.Uri
import android.os.Build
import android.os.Bundle
import android.os.Handler
import android.os.Looper
import android.provider.MediaStore
import android.view.Gravity
import android.view.View
import android.view.ViewGroup
import android.view.WindowManager
import android.view.animation.LinearInterpolator
import android.widget.*
import androidx.activity.result.contract.ActivityResultContracts
import androidx.appcompat.app.AppCompatActivity
import androidx.core.content.ContextCompat
import androidx.core.view.ViewCompat
import androidx.core.view.WindowCompat
import androidx.core.view.WindowInsetsCompat
import androidx.media3.common.MediaItem
import androidx.media3.common.Player
import androidx.media3.session.MediaController
import androidx.media3.session.SessionToken
import com.google.common.util.concurrent.ListenableFuture

 data class Track(val id: Long, val title: String, val artist: String, val albumId: Long, val uri: Uri)

class MainActivity : AppCompatActivity() {
    private val prefs by lazy { getSharedPreferences("void_tape", MODE_PRIVATE) }
    private var accent = Color.rgb(168, 255, 96)
    private var bg = Color.rgb(8, 9, 9)
    private var panel = Color.rgb(18, 20, 19)
    private var muted = Color.rgb(142, 150, 143)
    private var surfaceMode = 1 // 0 solid, 1 glass, 2 ghost
    private var wallpaperUri: Uri? = null
    private lateinit var root: FrameLayout
    private lateinit var wallpaper: ImageView
    private lateinit var content: LinearLayout
    private lateinit var glitch: GlitchView
    private lateinit var list: LinearLayout
    private lateinit var libraryScreen: ScrollView
    private lateinit var nowScreen: LinearLayout
    private lateinit var settingsScreen: ScrollView
    private lateinit var nowTitle: TextView
    private lateinit var nowArtist: TextView
    private lateinit var playButton: TextView
    private lateinit var status: TextView
    private lateinit var cover: ImageView
    private lateinit var progress: SeekBar
    private lateinit var elapsed: TextView
    private lateinit var duration: TextView
    private lateinit var shuffleButton: TextView
    private lateinit var repeatButton: TextView
    private var controller: MediaController? = null
    private var controllerFuture: ListenableFuture<MediaController>? = null
    private val tracks = mutableListOf<Track>()
    private val handler = Handler(Looper.getMainLooper())
    private var userSeeking = false
    private var currentTab = "LIBRARY"
    private var shuffle = false
    private var repeatMode = Player.REPEAT_MODE_OFF

    private val progressUpdater = object : Runnable {
        override fun run() {
            val c = controller
            if (c != null && !userSeeking) {
                val total = c.duration.takeIf { it > 0L } ?: 0L
                val position = c.currentPosition.coerceAtLeast(0L)
                progress.max = 1000
                progress.progress = if (total > 0L) ((position.toDouble() / total) * 1000).toInt().coerceIn(0, 1000) else 0
                elapsed.text = formatTime(position)
                duration.text = formatTime(total)
            }
            handler.postDelayed(this, 500L)
        }
    }

    private val permissionLauncher = registerForActivityResult(ActivityResultContracts.RequestPermission()) {
        if (it) loadTracks() else status.text = "НУЖЕН ДОСТУП К ЛОКАЛЬНЫМ АУДИОФАЙЛАМ"
    }
    private val wallpaperPicker = registerForActivityResult(ActivityResultContracts.OpenDocument()) { uri ->
        if (uri != null) {
            try { contentResolver.takePersistableUriPermission(uri, Intent.FLAG_GRANT_READ_URI_PERMISSION) } catch (_: Exception) { }
            wallpaperUri = uri
            prefs.edit().putString("wallpaper", uri.toString()).apply()
            applyWallpaper()
            applySurfaceStyle()
            glitch.flash()
        }
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        // Draw the wallpaper behind system bars, but keep interactive content inside safe insets.
        WindowCompat.setDecorFitsSystemWindows(window, false)
        window.statusBarColor = Color.TRANSPARENT
        window.navigationBarColor = Color.TRANSPARENT
        window.decorView.systemUiVisibility = 0
        loadPreferences()
        buildUi()
        connectController()
        val permission = if (Build.VERSION.SDK_INT >= 33) Manifest.permission.READ_MEDIA_AUDIO else Manifest.permission.READ_EXTERNAL_STORAGE
        if (ContextCompat.checkSelfPermission(this, permission) == PackageManager.PERMISSION_GRANTED) loadTracks() else permissionLauncher.launch(permission)
        handler.post(progressUpdater)
    }

    private fun loadPreferences() {
        accent = colorFor(prefs.getString("theme", "green") ?: "green")
        surfaceMode = prefs.getInt("surface", 1)
        wallpaperUri = prefs.getString("wallpaper", null)?.let { Uri.parse(it) }
    }

    private fun buildUi() {
        root = FrameLayout(this).apply { setBackgroundColor(bg) }
        wallpaper = ImageView(this).apply { scaleType = ImageView.ScaleType.CENTER_CROP; alpha = 0.38f }
        root.addView(wallpaper, FrameLayout.LayoutParams(-1, -1))
        content = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(dp(18), dp(8), dp(18), dp(8))
        }
        root.addView(content, FrameLayout.LayoutParams(-1, -1))
        ViewCompat.setOnApplyWindowInsetsListener(root) { _, insets ->
            val safe = insets.getInsets(
                WindowInsetsCompat.Type.systemBars() or WindowInsetsCompat.Type.displayCutout()
            )
            content.setPadding(
                maxOf(dp(18), safe.left + dp(18)),
                safe.top + dp(8),
                maxOf(dp(18), safe.right + dp(18)),
                safe.bottom + dp(8)
            )
            insets
        }
        ViewCompat.requestApplyInsets(root)
        glitch = GlitchView()
        root.addView(glitch, FrameLayout.LayoutParams(-1, -1))
        glitch.isClickable = false
        setContentView(root)

        val brandRow = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL; gravity = Gravity.CENTER_VERTICAL }
        brandRow.addView(TextView(this).apply {
            text = "V O I D   T A P E"
            textSize = 16f; letterSpacing = .08f; setTextColor(accent); typeface = Typeface.MONOSPACE
        }, LinearLayout.LayoutParams(0, dp(34), 1f))
        brandRow.addView(TextView(this).apply {
            text = "● OFFLINE"; textSize = 10f; setTextColor(accent); typeface = Typeface.MONOSPACE; gravity = Gravity.CENTER_VERTICAL
        })
        content.addView(brandRow)

        val tabs = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL; gravity = Gravity.CENTER; setPadding(0, dp(5), 0, dp(8)) }
        tabs.addView(tabButton("[ БИБЛИОТЕКА ]", "LIBRARY"), LinearLayout.LayoutParams(0, dp(40), 1f))
        tabs.addView(tabButton("[ PLAY ]", "NOW"), LinearLayout.LayoutParams(0, dp(40), 1f))
        tabs.addView(tabButton("[ НАСТРОЙКИ ]", "SETTINGS"), LinearLayout.LayoutParams(0, dp(40), 1f))
        content.addView(tabs)
        content.addView(separator(), LinearLayout.LayoutParams(-1, dp(1)))

        libraryScreen = ScrollView(this).apply { clipToPadding = false; setPadding(0, dp(8), 0, dp(8)) }
        val libraryBody = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL }
        libraryBody.addView(TextView(this).apply {
            text = "АРХИВ СИГНАЛА"; textSize = 24f; setTextColor(Color.WHITE); typeface = Typeface.create("sans-serif-black", Typeface.BOLD)
        }, LinearLayout.LayoutParams(-1, dp(42)))
        status = TextView(this).apply { text = "СКАНИРОВАНИЕ ЛОКАЛЬНОЙ БИБЛИОТЕКИ…"; textSize = 10f; setTextColor(muted); typeface = Typeface.MONOSPACE }
        libraryBody.addView(status, LinearLayout.LayoutParams(-1, dp(30)))
        list = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL }
        libraryBody.addView(list)
        libraryScreen.addView(libraryBody)
        content.addView(libraryScreen, LinearLayout.LayoutParams(-1, 0, 1f))

        nowScreen = buildNowScreen()
        content.addView(nowScreen, LinearLayout.LayoutParams(-1, 0, 1f))
        settingsScreen = buildSettingsScreen()
        content.addView(settingsScreen, LinearLayout.LayoutParams(-1, 0, 1f))
        showTab("LIBRARY", false)
        applyWallpaper()
        applySurfaceStyle()
        applyThemeToViews(content)
    }

    private fun buildNowScreen(): LinearLayout {
        val screen = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL; setPadding(0, dp(12), 0, dp(8)) }
        screen.addView(TextView(this).apply { text = "СЕЙЧАС В ЭФИРЕ"; textSize = 10f; letterSpacing = .16f; setTextColor(accent); typeface = Typeface.MONOSPACE }, LinearLayout.LayoutParams(-1, dp(26)))
        val coverFrame = FrameLayout(this).apply {
            background = ColorDrawable(Color.rgb(21, 25, 21))
            cover = ImageView(this@MainActivity).apply { scaleType = ImageView.ScaleType.CENTER_CROP; contentDescription = "Обложка альбома" }
            addView(cover, FrameLayout.LayoutParams(-1, -1))
            addView(TextView(this@MainActivity).apply { text = "VT\nNO SIGNAL"; gravity = Gravity.CENTER; textSize = 24f; setTextColor(accent); typeface = Typeface.MONOSPACE }, FrameLayout.LayoutParams(-1, -1).apply { gravity = Gravity.CENTER })
        }
        screen.addView(coverFrame, LinearLayout.LayoutParams(-1, 0, 1.3f).apply { bottomMargin = dp(14) })
        nowTitle = TextView(this).apply { text = "КАССЕТА НЕ ВСТАВЛЕНА"; textSize = 22f; setTextColor(Color.WHITE); typeface = Typeface.MONOSPACE; maxLines = 2; ellipsize = android.text.TextUtils.TruncateAt.END }
        nowArtist = TextView(this).apply { text = "Выбери трек в библиотеке"; textSize = 12f; setTextColor(muted); typeface = Typeface.MONOSPACE; maxLines = 1; ellipsize = android.text.TextUtils.TruncateAt.END }
        screen.addView(nowTitle, LinearLayout.LayoutParams(-1, dp(58)))
        screen.addView(nowArtist, LinearLayout.LayoutParams(-1, dp(26)))
        val wave = TextView(this).apply { text = "▁ ▃ ▂ ▅ ▇ ▃ ▆ ▂ ▄ ▇ ▅ ▂ ▆ ▃ ▇ ▂ ▄ ▅ ▂ ▇ ▃"; gravity = Gravity.CENTER; textSize = 18f; setTextColor(accent); typeface = Typeface.MONOSPACE }
        screen.addView(wave, LinearLayout.LayoutParams(-1, dp(34)))
        val timeRow = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL; gravity = Gravity.CENTER_VERTICAL }
        elapsed = monoLabel("0:00", muted); duration = monoLabel("0:00", muted).apply { gravity = Gravity.END }
        timeRow.addView(elapsed, LinearLayout.LayoutParams(0, dp(22), 1f)); timeRow.addView(duration, LinearLayout.LayoutParams(0, dp(22), 1f)); screen.addView(timeRow)
        progress = SeekBar(this).apply {
            max = 1000; progress = 0; progressTintList = android.content.res.ColorStateList.valueOf(accent); thumbTintList = android.content.res.ColorStateList.valueOf(accent)
            progressBackgroundTintList = android.content.res.ColorStateList.valueOf(Color.rgb(67, 71, 67)); setPadding(0, 0, 0, 0)
            setOnSeekBarChangeListener(object : SeekBar.OnSeekBarChangeListener {
                override fun onStartTrackingTouch(seekBar: SeekBar?) { userSeeking = true }
                override fun onProgressChanged(seekBar: SeekBar?, value: Int, fromUser: Boolean) { if (fromUser) { val total = controller?.duration?.takeIf { it > 0L } ?: 0L; elapsed.text = formatTime(total * value / 1000) } }
                override fun onStopTrackingTouch(seekBar: SeekBar?) { val c = controller; val total = c?.duration?.takeIf { it > 0L } ?: 0L; if (c != null && total > 0L) c.seekTo(total * (seekBar?.progress ?: 0) / 1000); userSeeking = false }
            })
        }
        screen.addView(progress, LinearLayout.LayoutParams(-1, dp(26)))
        val controls = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL; gravity = Gravity.CENTER }
        shuffleButton = controlButton("⤨", 0) { shuffle = !shuffle; controller?.shuffleModeEnabled = shuffle; updateControlTints() }
        val prev = controlButton("|◀", 0) { controller?.seekToPreviousMediaItem() }
        playButton = controlButton("▶", 1) { togglePlayback() }
        val next = controlButton("▶|", 0) { controller?.seekToNextMediaItem() }
        repeatButton = controlButton("↻", 0) { repeatMode = when (repeatMode) { Player.REPEAT_MODE_OFF -> Player.REPEAT_MODE_ALL; Player.REPEAT_MODE_ALL -> Player.REPEAT_MODE_ONE; else -> Player.REPEAT_MODE_OFF }; controller?.repeatMode = repeatMode; updateControlTints() }
        listOf(shuffleButton, prev, playButton, next, repeatButton).forEachIndexed { i, button -> controls.addView(button, LinearLayout.LayoutParams(0, dp(if (i == 2) 58 else 48), if (i == 2) 1.25f else 1f)) }
        screen.addView(controls)
        return screen
    }

    private fun buildSettingsScreen(): ScrollView {
        val scroll = ScrollView(this).apply { setPadding(0, dp(12), 0, dp(12)) }
        val body = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL }
        body.addView(sectionTitle("ЦВЕТ ФОСФОРА"))
        body.addView(TextView(this).apply { text = "Выбери цвет терминала"; textSize = 12f; setTextColor(muted) }, LinearLayout.LayoutParams(-1, dp(28)))
        val colors = listOf("green" to "ЗЕЛЁНЫЙ", "blue" to "СИНИЙ", "red" to "КРАСНЫЙ", "cyan" to "ГОЛУБОЙ", "yellow" to "ЖЁЛТЫЙ", "white" to "БЕЛЫЙ")
        colors.chunked(3).forEach { group ->
            val row = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL }
            group.forEach { (key, name) ->
                val swatch = TextView(this).apply {
                    text = "●  $name"; textSize = 10f; typeface = Typeface.MONOSPACE; setTextColor(colorFor(key)); gravity = Gravity.CENTER; isClickable = true; isFocusable = true
                    setOnClickListener {
                        prefs.edit().putString("theme", key).apply()
                        accent = colorFor(key)
                        val tab = currentTab
                        buildUi()
                        loadTracks()
                        showTab(tab, false)
                        glitch.flash()
                    }
                }
                row.addView(swatch, LinearLayout.LayoutParams(0, dp(48), 1f).apply { marginEnd = dp(5) })
            }
            body.addView(row)
        }
        body.addView(separator(), LinearLayout.LayoutParams(-1, dp(1)).apply { topMargin = dp(12); bottomMargin = dp(14) })
        body.addView(sectionTitle("ОБОИ"))
        body.addView(TextView(this).apply { text = "Выбери изображение из галереи телефона"; textSize = 12f; setTextColor(muted) }, LinearLayout.LayoutParams(-1, dp(30)))
        body.addView(settingButton("[ ВЫБРАТЬ ИЗОБРАЖЕНИЕ ]") { wallpaperPicker.launch(arrayOf("image/*")) })
        body.addView(settingButton("[ УБРАТЬ ОБОИ ]") { wallpaperUri = null; prefs.edit().remove("wallpaper").apply(); applyWallpaper(); applySurfaceStyle(); glitch.flash() })
        body.addView(separator(), LinearLayout.LayoutParams(-1, dp(1)).apply { topMargin = dp(12); bottomMargin = dp(14) })
        body.addView(sectionTitle("ПРОЗРАЧНОСТЬ ИНТЕРФЕЙСА"))
        body.addView(TextView(this).apply { text = "Меняет панели, сохраняя читаемость текста и кнопок."; textSize = 12f; setTextColor(muted) }, LinearLayout.LayoutParams(-1, dp(42)))
        val modes = listOf("SOLID" to 0, "GLASS" to 1, "GHOST" to 2)
        modes.forEach { (label, value) -> body.addView(settingButton("[ $label ]" + if (surfaceMode == value) "  ✓" else "") { surfaceMode = value; prefs.edit().putInt("surface", value).apply(); applySurfaceStyle(); glitch.flash(); buildSettingsRefresh() }) }
        body.addView(separator(), LinearLayout.LayoutParams(-1, dp(1)).apply { topMargin = dp(12); bottomMargin = dp(14) })
        body.addView(sectionTitle("СИГНАЛ"))
        body.addView(TextView(this).apply { text = "VOID TAPE / OFFLINE PLAYER\nАудио остаётся на устройстве. Настройки сохраняются."; textSize = 11f; setTextColor(muted); typeface = Typeface.MONOSPACE }, LinearLayout.LayoutParams(-1, dp(54)))
        scroll.addView(body)
        return scroll
    }

    private fun buildSettingsRefresh() {
        val old = settingsScreen
        val replacement = buildSettingsScreen()
        val index = content.indexOfChild(old)
        if (index >= 0) {
            content.removeViewAt(index)
            content.addView(replacement, index, LinearLayout.LayoutParams(-1, 0, 1f))
        }
        settingsScreen = replacement
        applySurfaceStyle()
        showTab(currentTab, false)
    }

    private fun tabButton(label: String, tab: String): TextView = TextView(this).apply {
        text = label; textSize = 10f; gravity = Gravity.CENTER; typeface = Typeface.MONOSPACE; setTextColor(if (currentTab == tab) accent else muted); isClickable = true; isFocusable = true
        setOnClickListener { showTab(tab, true) }
    }

    private fun showTab(tab: String, animate: Boolean) {
        currentTab = tab
        libraryScreen.visibility = if (tab == "LIBRARY") View.VISIBLE else View.GONE
        nowScreen.visibility = if (tab == "NOW") View.VISIBLE else View.GONE
        settingsScreen.visibility = if (tab == "SETTINGS") View.VISIBLE else View.GONE
        // Update tab labels without rebuilding their hierarchy.
        val tabRow = content.getChildAt(1) as? LinearLayout
        tabRow?.let { row -> for (i in 0 until row.childCount) { val v = row.getChildAt(i) as? TextView ?: continue; v.setTextColor(if ((i == 0 && tab == "LIBRARY") || (i == 1 && tab == "NOW") || (i == 2 && tab == "SETTINGS")) accent else muted) } }
        if (animate) glitch.flash()
    }

    private fun loadTracks() {
        tracks.clear()
        val collection = MediaStore.Audio.Media.EXTERNAL_CONTENT_URI
        val projection = arrayOf(MediaStore.Audio.Media._ID, MediaStore.Audio.Media.TITLE, MediaStore.Audio.Media.ARTIST, MediaStore.Audio.Media.ALBUM_ID)
        try {
            contentResolver.query(collection, projection, "${MediaStore.Audio.Media.IS_MUSIC} != 0", null, "${MediaStore.Audio.Media.TITLE} COLLATE NOCASE ASC")?.use { c: Cursor ->
                val idCol = c.getColumnIndexOrThrow(MediaStore.Audio.Media._ID); val titleCol = c.getColumnIndexOrThrow(MediaStore.Audio.Media.TITLE); val artistCol = c.getColumnIndexOrThrow(MediaStore.Audio.Media.ARTIST); val albumCol = c.getColumnIndexOrThrow(MediaStore.Audio.Media.ALBUM_ID)
                while (c.moveToNext()) {
                    val id = c.getLong(idCol); val title = c.getString(titleCol)?.takeUnless { it.isBlank() || it.equals("<unknown>", true) } ?: "БЕЗ НАЗВАНИЯ"
                    val artist = c.getString(artistCol)?.takeUnless { it.isBlank() || it.equals("<unknown>", true) } ?: "НЕИЗВЕСТНЫЙ ИСПОЛНИТЕЛЬ"
                    tracks.add(Track(id, title, artist, c.getLong(albumCol), android.content.ContentUris.withAppendedId(collection, id)))
                }
            }
        } catch (_: Exception) { }
        list.removeAllViews()
        status.text = if (tracks.isEmpty()) "СИГНАЛ НЕ НАЙДЕН · ДОБАВЬ МУЗЫКУ НА УСТРОЙСТВО" else "ЛОКАЛЬНЫЙ АРХИВ  ·  ${tracks.size} ТРЕКОВ"
        tracks.forEachIndexed { index, track ->
            val row = LinearLayout(this).apply {
                orientation = LinearLayout.HORIZONTAL; gravity = Gravity.CENTER_VERTICAL; setPadding(dp(10), dp(8), dp(10), dp(8)); setBackgroundColor(if (index % 2 == 0) surfaceColor() else Color.TRANSPARENT); isClickable = true; isFocusable = true
                setOnClickListener { playTrack(index); showTab("NOW", true) }
            }
            row.addView(TextView(this).apply { text = "▣"; textSize = 18f; setTextColor(accent); gravity = Gravity.CENTER; typeface = Typeface.MONOSPACE }, LinearLayout.LayoutParams(dp(38), dp(48)))
            val labels = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL; gravity = Gravity.CENTER_VERTICAL }
            labels.addView(TextView(this).apply { text = track.title; textSize = 13f; setTextColor(Color.WHITE); typeface = Typeface.MONOSPACE; maxLines = 1; ellipsize = android.text.TextUtils.TruncateAt.END })
            labels.addView(TextView(this).apply { text = track.artist; textSize = 10f; setTextColor(muted); typeface = Typeface.MONOSPACE; maxLines = 1; ellipsize = android.text.TextUtils.TruncateAt.END })
            row.addView(labels, LinearLayout.LayoutParams(0, -1, 1f))
            row.addView(TextView(this).apply { text = "▶"; textSize = 12f; setTextColor(accent); gravity = Gravity.CENTER }, LinearLayout.LayoutParams(dp(30), dp(48)))
            list.addView(row, LinearLayout.LayoutParams(-1, dp(64))); list.addView(separator(), LinearLayout.LayoutParams(-1, dp(1)))
        }
        updateNowPlaying()
    }

    private fun playTrack(index: Int) {
        val c = controller ?: run { status.text = "ПЛЕЕР ЗАПУСКАЕТСЯ · ПОВТОРИ ЧЕРЕЗ СЕКУНДУ"; return }
        c.setMediaItems(tracks.map { MediaItem.fromUri(it.uri) }, index, 0L); c.prepare(); c.play(); updateNowPlaying(); glitch.flash()
    }

    private fun togglePlayback() {
        val c = controller ?: return
        if (c.isPlaying) c.pause() else { if (c.mediaItemCount == 0 && tracks.isNotEmpty()) playTrack(0) else c.play() }
        playButton.text = if (c.isPlaying) "Ⅱ" else "▶"
    }

    private fun connectController() {
        val token = SessionToken(this, ComponentName(this, PlaybackService::class.java))
        controllerFuture = MediaController.Builder(this, token).buildAsync()
        controllerFuture?.addListener({
            try {
                controller = controllerFuture?.get()
                controller?.addListener(object : Player.Listener {
                    override fun onMediaItemTransition(mediaItem: MediaItem?, reason: Int) { updateNowPlaying(); glitch.flash() }
                    override fun onIsPlayingChanged(isPlaying: Boolean) { playButton.text = if (isPlaying) "Ⅱ" else "▶" }
                    override fun onPlaybackStateChanged(playbackState: Int) { updateNowPlaying() }
                })
                updateNowPlaying()
            } catch (_: Exception) { status.text = "ОШИБКА СВЯЗИ С ПЛЕЕРОМ" }
        }, ContextCompat.getMainExecutor(this))
    }

    private fun updateNowPlaying() {
        val c = controller ?: return
        val index = c.currentMediaItemIndex
        if (index in tracks.indices) {
            val track = tracks[index]; nowTitle.text = track.title; nowArtist.text = track.artist
            var hasCover = false
            if (track.albumId > 0L) try { contentResolver.openInputStream(Uri.parse("content://media/external/audio/albumart/${track.albumId}"))?.use { cover.setImageBitmap(BitmapFactory.decodeStream(it)); hasCover = cover.drawable != null } } catch (_: Exception) { }
            if (!hasCover) cover.setImageDrawable(null)
        } else { nowTitle.text = "КАССЕТА НЕ ВСТАВЛЕНА"; nowArtist.text = "Выбери трек в библиотеке"; cover.setImageDrawable(null) }
        playButton.text = if (c.isPlaying) "Ⅱ" else "▶"
        updateControlTints()
    }

    private fun updateControlTints() {
        shuffleButton.setTextColor(if (shuffle) accent else muted)
        repeatButton.setTextColor(if (repeatMode != Player.REPEAT_MODE_OFF) accent else muted)
        progress.progressTintList = android.content.res.ColorStateList.valueOf(accent); progress.thumbTintList = android.content.res.ColorStateList.valueOf(accent)
    }

    private fun applyWallpaper() {
        if (wallpaperUri == null) { wallpaper.setImageDrawable(null); wallpaper.visibility = View.GONE; return }
        wallpaper.visibility = View.VISIBLE
        try { wallpaper.setImageURI(wallpaperUri) } catch (_: Exception) { wallpaper.setImageDrawable(null) }
    }

    private fun applySurfaceStyle() {
        val hasWallpaper = wallpaperUri != null
        wallpaper.alpha = when (surfaceMode) { 0 -> 0.18f; 1 -> 0.42f; else -> 0.72f }
        val panelAlpha = when (surfaceMode) { 0 -> 255; 1 -> 190; else -> 35 }
        fun styleRows(view: View) {
            if (view is LinearLayout) {
                if (view !== content && (view.orientation == LinearLayout.VERTICAL || view.orientation == LinearLayout.HORIZONTAL)) {
                    // Panels remain subtle in ghost mode; only structural containers are transparent.
                    view.setBackgroundColor(Color.argb(if (hasWallpaper) panelAlpha else if (surfaceMode == 2) 0 else 255, 8, 9, 9))
                }
                for (i in 0 until view.childCount) styleRows(view.getChildAt(i))
            } else if (view is ViewGroup) for (i in 0 until view.childCount) styleRows(view.getChildAt(i))
        }
        styleRows(content)
        content.setBackgroundColor(Color.TRANSPARENT)
        libraryScreen.setBackgroundColor(Color.TRANSPARENT); nowScreen.setBackgroundColor(Color.TRANSPARENT); settingsScreen.setBackgroundColor(Color.TRANSPARENT)
        playerPanelStyle()
    }

    private fun playerPanelStyle() { /* The now-playing layout intentionally stays open over the wallpaper. */ }

    private fun applyThemeToViews(view: View) {
        if (view is TextView) {
            val text = view.text?.toString().orEmpty()
            if (text.contains("V O I D") || text.contains("OFFLINE") || text.contains("СЕЙЧАС В ЭФИРЕ") || text.contains("▁") || text == "VT") view.setTextColor(accent)
        }
        if (view is SeekBar) { view.progressTintList = android.content.res.ColorStateList.valueOf(accent); view.thumbTintList = android.content.res.ColorStateList.valueOf(accent) }
        if (view is ViewGroup) for (i in 0 until view.childCount) applyThemeToViews(view.getChildAt(i))
        updateControlTints()
    }

    private fun controlButton(label: String, prominent: Int, action: () -> Unit): TextView = TextView(this).apply {
        text = label; textSize = if (prominent == 1) 26f else 18f; setTextColor(accent); gravity = Gravity.CENTER; typeface = Typeface.MONOSPACE
        background = if (prominent == 1) ColorDrawable(surfaceColor()) else ColorDrawable(Color.TRANSPARENT)
        isClickable = true; isFocusable = true; setOnClickListener { action() }
    }
    private fun settingButton(label: String, action: () -> Unit) = TextView(this).apply {
        text = label; textSize = 12f; setTextColor(accent); typeface = Typeface.MONOSPACE; gravity = Gravity.CENTER_VERTICAL; setPadding(dp(12), 0, dp(12), 0); background = ColorDrawable(surfaceColor()); isClickable = true; isFocusable = true; setOnClickListener { action() }
        layoutParams = LinearLayout.LayoutParams(-1, dp(48)).apply { bottomMargin = dp(6) }
    }
    private fun sectionTitle(text: String) = TextView(this).apply { this.text = text; textSize = 13f; setTextColor(accent); typeface = Typeface.MONOSPACE; gravity = Gravity.CENTER_VERTICAL }
    private fun monoLabel(text: String, color: Int) = TextView(this).apply { this.text = text; textSize = 10f; setTextColor(color); typeface = Typeface.MONOSPACE }
    private fun separator() = View(this).apply { setBackgroundColor(Color.argb(120, Color.red(accent), Color.green(accent), Color.blue(accent))) }
    private fun surfaceColor(): Int = when (surfaceMode) { 0 -> Color.rgb(18, 20, 19); 1 -> Color.argb(205, 18, 20, 19); else -> Color.argb(65, 18, 20, 19) }
    private fun colorFor(key: String): Int = when (key) {
        "blue" -> Color.rgb(80, 145, 255); "red" -> Color.rgb(255, 75, 75); "cyan" -> Color.rgb(70, 240, 255)
        "yellow" -> Color.rgb(255, 218, 86); "white" -> Color.rgb(238, 241, 235); else -> Color.rgb(168, 255, 96)
    }
    private fun formatTime(ms: Long): String { if (ms <= 0L) return "0:00"; val s = ms / 1000; return "${s / 60}:${(s % 60).toString().padStart(2, '0')}" }
    private fun dp(value: Int) = (value * resources.displayMetrics.density).toInt()

    private inner class GlitchView : View(this@MainActivity) {
        private val paint = Paint(Paint.ANTI_ALIAS_FLAG)
        private var intensity = 0f
        private var animator: ValueAnimator? = null
        fun flash() {
            animator?.cancel()
            animator = ValueAnimator.ofFloat(0f, 1f, .15f, .8f, 0f).apply {
                duration = 420L; interpolator = LinearInterpolator()
                addUpdateListener { intensity = it.animatedValue as Float; invalidate() }; start()
            }
        }
        override fun onDraw(canvas: Canvas) {
            super.onDraw(canvas)
            // Persistent subtle CRT scanlines, with short horizontal tears during transitions.
            paint.color = Color.argb(24, 0, 0, 0); paint.strokeWidth = dp(1).toFloat()
            var y = 0f; while (y < height) { canvas.drawLine(0f, y, width.toFloat(), y, paint); y += dp(3).toFloat() }
            if (intensity > .05f) {
                paint.color = Color.argb((intensity * 58).toInt().coerceIn(0, 58), Color.red(accent), Color.green(accent), Color.blue(accent))
                val bandH = dp(3).toFloat()
                for (i in 0..5) { val yy = ((height * ((i * 0.173f + intensity * 0.37f) % 1f))); canvas.drawRect(0f, yy, width.toFloat() * (if (i % 2 == 0) .72f else 1f), yy + bandH, paint) }
                paint.color = Color.argb((intensity * 30).toInt(), 255, 255, 255)
                canvas.drawRect(0f, height * .48f, width.toFloat(), height * .48f + dp(2), paint)
            }
        }
    }

    override fun onDestroy() {
        handler.removeCallbacks(progressUpdater)
        controllerFuture?.let { MediaController.releaseFuture(it) }
        super.onDestroy()
    }
}
