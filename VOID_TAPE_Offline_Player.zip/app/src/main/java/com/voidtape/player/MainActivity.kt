package com.voidtape.player

import android.Manifest
import android.animation.ValueAnimator
import android.content.ComponentName
import android.content.Intent
import android.content.pm.PackageManager
import android.database.Cursor
import android.graphics.BitmapFactory
import android.graphics.Canvas
import android.graphics.Color
import android.graphics.Paint
import android.graphics.Typeface
import android.graphics.drawable.ColorDrawable
import android.graphics.drawable.GradientDrawable
import android.media.AudioManager
import android.media.ToneGenerator
import android.net.Uri
import android.os.Build
import android.os.Bundle
import android.os.Handler
import android.os.Looper
import android.provider.MediaStore
import android.view.Gravity
import android.view.View
import android.view.ViewGroup
import android.view.WindowManager
import android.view.animation.LinearInterpolator
import android.widget.*
import androidx.activity.result.contract.ActivityResultContracts
import androidx.appcompat.app.AppCompatActivity
import androidx.core.content.ContextCompat
import androidx.core.view.ViewCompat
import androidx.core.view.WindowCompat
import androidx.core.view.WindowInsetsCompat
import androidx.media3.common.MediaItem
import androidx.media3.common.Player
import androidx.media3.session.MediaController
import androidx.media3.session.SessionToken
import com.google.common.util.concurrent.ListenableFuture

 data class Track(val id: Long, val title: String, val artist: String, val albumId: Long, val uri: Uri)

class MainActivity : AppCompatActivity() {
    private val prefs by lazy { getSharedPreferences("aero_tape", MODE_PRIVATE) }
    private var accent = Color.rgb(72, 226, 238)
    private var bg = Color.rgb(7, 28, 43)
    private var panel = Color.rgb(22, 73, 94)
    private var muted = Color.rgb(178, 225, 231)
    private var surfaceMode = 1 // 0 solid, 1 glass, 2 ghost
    private var splashEnabled = true
    private var signalsEnabled = true
    private var splashOverlay: View? = null
    private var wallpaperUri: Uri? = null
    private lateinit var root: FrameLayout
    private lateinit var wallpaper: ImageView
    private lateinit var content: LinearLayout
    private lateinit var glitch: GlitchView
    private lateinit var list: LinearLayout
    private lateinit var playlistContainer: LinearLayout
    private val playlistNames = mutableListOf<String>()
    private val playlistTracks = mutableMapOf<String, MutableSet<Long>>()
    private lateinit var libraryScreen: ScrollView
    private lateinit var nowScreen: LinearLayout
    private lateinit var settingsScreen: ScrollView
    private lateinit var nowTitle: TextView
    private lateinit var nowArtist: TextView
    private lateinit var playButton: TextView
    private lateinit var status: TextView
    private lateinit var cover: ImageView
    private lateinit var progress: SeekBar
    private lateinit var elapsed: TextView
    private lateinit var duration: TextView
    private lateinit var shuffleButton: TextView
    private lateinit var repeatButton: TextView
    private var controller: MediaController? = null
    private var controllerFuture: ListenableFuture<MediaController>? = null
    private val tracks = mutableListOf<Track>()
    private val handler = Handler(Looper.getMainLooper())
    private var userSeeking = false
    private var currentTab = "LIBRARY"
    private var shuffle = false
    private var repeatMode = Player.REPEAT_MODE_OFF

    private val progressUpdater = object : Runnable {
        override fun run() {
            val c = controller
            if (c != null && !userSeeking) {
                val total = c.duration.takeIf { it > 0L } ?: 0L
                val position = c.currentPosition.coerceAtLeast(0L)
                progress.max = 1000
                progress.progress = if (total > 0L) ((position.toDouble() / total) * 1000).toInt().coerceIn(0, 1000) else 0
                elapsed.text = formatTime(position)
                duration.text = formatTime(total)
            }
            handler.postDelayed(this, 500L)
        }
    }

    private val permissionLauncher = registerForActivityResult(ActivityResultContracts.RequestPermission()) {
        if (it) loadTracks() else status.text = "НУЖЕН ДОСТУП К ЛОКАЛЬНЫМ АУДИОФАЙЛАМ"
    }
    private val wallpaperPicker = registerForActivityResult(ActivityResultContracts.OpenDocument()) { uri ->
        if (uri != null) {
            try { contentResolver.takePersistableUriPermission(uri, Intent.FLAG_GRANT_READ_URI_PERMISSION) } catch (_: Exception) { }
            wallpaperUri = uri
            prefs.edit().putString("wallpaper", uri.toString()).apply()
            applyWallpaper()
            applySurfaceStyle()
            glitch.flash()
        }
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        WindowCompat.setDecorFitsSystemWindows(window, true)
        window.statusBarColor = Color.rgb(5, 24, 38)
        window.navigationBarColor = Color.rgb(5, 24, 38)
        window.decorView.systemUiVisibility = 0
        loadPreferences()
        buildUi()
        connectController()
        val permission = if (Build.VERSION.SDK_INT >= 33) Manifest.permission.READ_MEDIA_AUDIO else Manifest.permission.READ_EXTERNAL_STORAGE
        if (ContextCompat.checkSelfPermission(this, permission) == PackageManager.PERMISSION_GRANTED) loadTracks() else permissionLauncher.launch(permission)
        handler.post(progressUpdater)
        if (splashEnabled) showAeroSplash()
    }

    private fun loadPreferences() {
        accent = colorFor(prefs.getString("theme", "aqua") ?: "aqua")
        splashEnabled = prefs.getBoolean("splash", true)
        signalsEnabled = prefs.getBoolean("signals", true)
        surfaceMode = prefs.getInt("surface", 1)
        wallpaperUri = prefs.getString("wallpaper", null)?.let { Uri.parse(it) }
        playlistNames.clear(); playlistTracks.clear()
        try {
            val saved = org.json.JSONArray(prefs.getString("playlists", "[]") ?: "[]")
            for (i in 0 until saved.length()) {
                val item = saved.getJSONObject(i); val name = item.optString("name").trim()
                if (name.isNotEmpty() && !playlistNames.contains(name)) {
                    playlistNames.add(name)
                    val ids = mutableSetOf<Long>(); val arr = item.optJSONArray("tracks") ?: org.json.JSONArray()
                    for (j in 0 until arr.length()) ids.add(arr.optLong(j))
                    playlistTracks[name] = ids
                }
            }
        } catch (_: Exception) { }
    }

    private fun buildUi() {
        root = FrameLayout(this).apply {
            background = GradientDrawable(GradientDrawable.Orientation.TL_BR, intArrayOf(
                Color.rgb(77, 205, 225), Color.rgb(28, 151, 190), Color.rgb(47, 170, 155), Color.rgb(155, 213, 132)
            ))
        }
        wallpaper = ImageView(this).apply { scaleType = ImageView.ScaleType.CENTER_CROP; alpha = 0.62f }
        root.addView(wallpaper, FrameLayout.LayoutParams(-1, -1))
        content = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL; setPadding(dp(14), dp(6), dp(14), dp(6)) }
        root.addView(content, FrameLayout.LayoutParams(-1, -1))
        glitch = GlitchView(); root.addView(glitch, FrameLayout.LayoutParams(-1, -1)); glitch.isClickable = false
        setContentView(root)

        val top = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL; gravity = Gravity.CENTER_VERTICAL; setPadding(dp(10), 0, dp(10), 0); background = roundedGlass(Color.argb(150, 25, 131, 174), dp(18).toFloat(), Color.argb(190, 225, 255, 255)) }
        top.addView(TextView(this).apply { text = "◉  AERO TAPE"; textSize = 18f; letterSpacing = .03f; setTextColor(Color.WHITE); typeface = Typeface.create("sans-serif-light", Typeface.NORMAL) }, LinearLayout.LayoutParams(0, dp(46), 1f))
        top.addView(TextView(this).apply { text = "● ONLINE / LOCAL"; textSize = 9f; setTextColor(Color.rgb(218,255,230)); typeface = Typeface.MONOSPACE }, LinearLayout.LayoutParams(-2, dp(46)))
        content.addView(top, LinearLayout.LayoutParams(-1, dp(46)))

        val desktopLabel = TextView(this).apply { text = "WELCOME TO YOUR AUDIO WORLD"; textSize = 10f; letterSpacing = .12f; setTextColor(Color.WHITE); typeface = Typeface.MONOSPACE; setPadding(dp(6), dp(10), 0, dp(4)) }
        content.addView(desktopLabel, LinearLayout.LayoutParams(-1, dp(30)))
        val desktop = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL; gravity = Gravity.CENTER; setPadding(dp(4), dp(5), dp(4), dp(8)) }
        fun desktopIcon(symbol: String, label: String, tab: String) = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL; gravity = Gravity.CENTER; isClickable = true; isFocusable = true
            val orb = TextView(this@MainActivity).apply { text = symbol; textSize = 27f; gravity = Gravity.CENTER; setTextColor(Color.WHITE); background = roundedGlass(Color.argb(160, 83, 190, 221), dp(16).toFloat(), Color.argb(220, 240,255,255)); elevation = dp(5).toFloat() }
            addView(orb, LinearLayout.LayoutParams(dp(58), dp(52)))
            addView(TextView(this@MainActivity).apply { text = label; textSize = 10f; gravity = Gravity.CENTER; setTextColor(Color.WHITE); maxLines = 2 }, LinearLayout.LayoutParams(-1, dp(32)))
            setOnClickListener { showTab(tab, true) }
            setOnLongClickListener { if (tab == "LIBRARY") createPlaylistDialog(); true }
        }
        desktop.addView(desktopIcon("♫", "My Music", "LIBRARY"), LinearLayout.LayoutParams(0, dp(90), 1f))
        desktop.addView(desktopIcon("▶", "Aero Player", "NOW"), LinearLayout.LayoutParams(0, dp(90), 1f))
        desktop.addView(desktopIcon("⚙", "Settings", "SETTINGS"), LinearLayout.LayoutParams(0, dp(90), 1f))
        content.addView(desktop, LinearLayout.LayoutParams(-1, dp(94)))

        val desktopWidget = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            gravity = Gravity.CENTER_VERTICAL
            setPadding(dp(14), dp(8), dp(14), dp(8))
            background = roundedGlass(Color.argb(115, 222, 255, 248), dp(18).toFloat(), Color.argb(210, 255, 255, 255))
            elevation = dp(4).toFloat()
        }
        desktopWidget.addView(TextView(this).apply {
            text = "WELCOME TO YOUR AUDIO WORLD"
            textSize = 12f; letterSpacing = .08f; setTextColor(Color.rgb(12, 77, 99))
            typeface = Typeface.create("sans-serif-medium", Typeface.BOLD)
        }, LinearLayout.LayoutParams(-1, dp(24)))
        desktopWidget.addView(TextView(this).apply {
            text = "LOCAL ARCHIVE  •  YOUR MUSIC, YOUR SPACE"
            textSize = 9f; letterSpacing = .04f; setTextColor(Color.rgb(27, 105, 119))
            typeface = Typeface.create("sans-serif", Typeface.NORMAL)
        }, LinearLayout.LayoutParams(-1, dp(20)))
        content.addView(desktopWidget, LinearLayout.LayoutParams(-1, dp(58)).apply { topMargin = dp(5); bottomMargin = dp(8) })

        val tabs = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL; gravity = Gravity.CENTER; setPadding(dp(4), dp(3), dp(4), dp(3)); background = roundedGlass(Color.argb(155, 21, 91, 126), dp(14).toFloat(), Color.argb(170, 220,255,255)) }
        tabs.addView(tabButton("▦  MUSIC", "LIBRARY"), LinearLayout.LayoutParams(0, dp(36), 1f))
        tabs.addView(tabButton("▶  PLAYER", "NOW"), LinearLayout.LayoutParams(0, dp(36), 1f))
        tabs.addView(tabButton("⚙  SETTINGS", "SETTINGS"), LinearLayout.LayoutParams(0, dp(36), 1f))
        content.addView(tabs, LinearLayout.LayoutParams(-1, dp(42)))

        libraryScreen = ScrollView(this).apply { clipToPadding = false; setPadding(0, dp(8), 0, dp(8)) }
        val libraryBody = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL; background = roundedGlass(Color.argb(145, 19, 79, 107), dp(18).toFloat(), Color.argb(155, 220,255,255)); setPadding(dp(12), dp(10), dp(12), dp(10)) }
        libraryBody.addView(TextView(this).apply { text = "MY MUSIC"; textSize = 22f; setTextColor(Color.WHITE); typeface = Typeface.create("sans-serif-medium", Typeface.BOLD) }, LinearLayout.LayoutParams(-1, dp(38)))
        status = TextView(this).apply { text = "YOUR LOCAL SOUND COLLECTION"; textSize = 10f; setTextColor(muted); typeface = Typeface.MONOSPACE }
        libraryBody.addView(status, LinearLayout.LayoutParams(-1, dp(26)))
        libraryBody.addView(settingButton("＋  CREATE PLAYLIST FOLDER") { createPlaylistDialog() })
        playlistContainer = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL }
        libraryBody.addView(playlistContainer)
        list = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL }
        libraryBody.addView(list)
        libraryScreen.addView(libraryBody)
        content.addView(libraryScreen, LinearLayout.LayoutParams(-1, 0, 1f))
        nowScreen = buildNowScreen(); content.addView(nowScreen, LinearLayout.LayoutParams(-1, 0, 1f))
        settingsScreen = buildSettingsScreen(); content.addView(settingsScreen, LinearLayout.LayoutParams(-1, 0, 1f))

        val taskbar = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL; gravity = Gravity.CENTER
            setPadding(dp(5), dp(4), dp(5), dp(4))
            background = roundedGlass(Color.argb(190, 16, 104, 141), dp(18).toFloat(), Color.argb(230, 222, 255, 255))
            elevation = dp(8).toFloat()
        }
        fun task(label: String, tab: String) = TextView(this).apply {
            text = label; textSize = 10f; gravity = Gravity.CENTER; setTextColor(Color.WHITE)
            typeface = Typeface.create("sans-serif-medium", Typeface.NORMAL); isClickable = true; isFocusable = true
            setOnClickListener { showTab(tab, true) }
        }
        taskbar.addView(task("⊞  DESKTOP", "DESKTOP"), LinearLayout.LayoutParams(0, dp(36), 1.15f))
        taskbar.addView(task("♫  MUSIC", "LIBRARY"), LinearLayout.LayoutParams(0, dp(36), 1f))
        taskbar.addView(task("▶  PLAYER", "NOW"), LinearLayout.LayoutParams(0, dp(36), 1f))
        taskbar.addView(task("⚙", "SETTINGS"), LinearLayout.LayoutParams(0, dp(36), .55f))
        content.addView(taskbar, LinearLayout.LayoutParams(-1, dp(46)).apply { topMargin = dp(6) })

        showTab("DESKTOP", false); applyWallpaper(); applySurfaceStyle(); applyThemeToViews(content)
    }

    private fun savePlaylists() {
        val arr = org.json.JSONArray()
        playlistNames.forEach { name ->
            val item = org.json.JSONObject().put("name", name); val ids = org.json.JSONArray()
            playlistTracks[name].orEmpty().forEach { ids.put(it) }; item.put("tracks", ids); arr.put(item)
        }
        prefs.edit().putString("playlists", arr.toString()).apply()
    }

    private fun createPlaylistDialog() {
        val field = EditText(this).apply { hint = "Playlist name"; setSingleLine(true); setTextColor(Color.WHITE); setHintTextColor(muted) }
        android.app.AlertDialog.Builder(this).setTitle("Create music folder").setMessage("A folder becomes a playlist. Add tracks to it with a long press.").setView(field)
            .setNegativeButton("CANCEL", null).setPositiveButton("CREATE") { _, _ ->
                val name = field.text.toString().trim()
                if (name.isNotEmpty() && !playlistNames.contains(name)) { playlistNames.add(name); playlistTracks[name] = mutableSetOf(); savePlaylists(); renderPlaylists() }
            }.show()
    }

    private fun addTrackToPlaylist(track: Track) {
        if (playlistNames.isEmpty()) { createPlaylistDialog(); return }
        android.app.AlertDialog.Builder(this).setTitle(track.title).setItems(playlistNames.toTypedArray()) { _, which ->
            playlistTracks.getOrPut(playlistNames[which]) { mutableSetOf() }.add(track.id); savePlaylists(); renderPlaylists()
            Toast.makeText(this, "Added to ${playlistNames[which]}", Toast.LENGTH_SHORT).show()
        }.setNegativeButton("CANCEL", null).show()
    }

    private fun renderPlaylists() {
        if (!::playlistContainer.isInitialized) return
        playlistContainer.removeAllViews()
        playlistNames.forEach { name ->
            val row = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL; gravity = Gravity.CENTER_VERTICAL; background = roundedGlass(Color.argb(100, 114, 218, 230), dp(12).toFloat(), Color.argb(120,255,255,255)); setPadding(dp(10), 0, dp(6), 0) }
            row.addView(TextView(this).apply { text = "📁  $name  ·  ${playlistTracks[name]?.size ?: 0}"; textSize = 12f; setTextColor(Color.WHITE); maxLines = 1; ellipsize = android.text.TextUtils.TruncateAt.END }, LinearLayout.LayoutParams(0, dp(42), 1f))
            row.addView(TextView(this).apply { text = "⋯"; textSize = 24f; gravity = Gravity.CENTER; setTextColor(Color.WHITE); setPadding(dp(10),0,dp(10),0); setOnClickListener {
                android.app.AlertDialog.Builder(this@MainActivity).setTitle(name).setItems(arrayOf("Play this folder", "Rename", "Delete")) { _, choice ->
                    when(choice) {
                        0 -> { val ids = playlistTracks[name].orEmpty(); val chosen = tracks.filter { ids.contains(it.id) }; if (chosen.isNotEmpty()) { val c = controller; if (c != null) { c.setMediaItems(chosen.map { MediaItem.fromUri(it.uri) }); c.prepare(); c.play(); showTab("NOW", true) } } else Toast.makeText(this@MainActivity, "Folder is empty", Toast.LENGTH_SHORT).show() }
                        1 -> { val input = EditText(this@MainActivity).apply { setText(name); setSingleLine(true) }; android.app.AlertDialog.Builder(this@MainActivity).setTitle("Rename folder").setView(input).setNegativeButton("CANCEL", null).setPositiveButton("SAVE") { _, _ -> val nn=input.text.toString().trim(); if(nn.isNotEmpty() && (nn==name || !playlistNames.contains(nn))) { val ix=playlistNames.indexOf(name); playlistNames[ix]=nn; playlistTracks[nn]=playlistTracks.remove(name) ?: mutableSetOf(); savePlaylists(); renderPlaylists() } }.show() }
                        2 -> android.app.AlertDialog.Builder(this@MainActivity).setMessage("Delete playlist folder '$name'? The audio files will stay on your phone.").setNegativeButton("CANCEL",null).setPositiveButton("DELETE") { _, _ -> playlistNames.remove(name); playlistTracks.remove(name); savePlaylists(); renderPlaylists() }.show()
                    }
                }.show()
            } }, LinearLayout.LayoutParams(dp(42), dp(42)))
            playlistContainer.addView(row, LinearLayout.LayoutParams(-1, dp(44)).apply { bottomMargin = dp(5) })
        }
    }

    private fun buildNowScreen(): LinearLayout {
        val screen = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL; setPadding(0, dp(12), 0, dp(8)) }
        screen.addView(TextView(this).apply { text = "NOW PLAYING"; textSize = 10f; letterSpacing = .16f; setTextColor(accent); typeface = Typeface.MONOSPACE }, LinearLayout.LayoutParams(-1, dp(26)))
        val coverFrame = FrameLayout(this).apply {
            background = ColorDrawable(Color.rgb(21, 25, 21))
            cover = ImageView(this@MainActivity).apply { scaleType = ImageView.ScaleType.CENTER_CROP; contentDescription = "Обложка альбома" }
            addView(cover, FrameLayout.LayoutParams(-1, -1))
            addView(TextView(this@MainActivity).apply { text = "AERO\nTAPE"; gravity = Gravity.CENTER; textSize = 24f; setTextColor(accent); typeface = Typeface.MONOSPACE }, FrameLayout.LayoutParams(-1, -1).apply { gravity = Gravity.CENTER })
        }
        screen.addView(coverFrame, LinearLayout.LayoutParams(-1, 0, 1.3f).apply { bottomMargin = dp(14) })
        nowTitle = TextView(this).apply { text = "Choose your soundtrack"; textSize = 22f; setTextColor(Color.WHITE); typeface = Typeface.MONOSPACE; maxLines = 2; ellipsize = android.text.TextUtils.TruncateAt.END }
        nowArtist = TextView(this).apply { text = "A little piece of your world"; textSize = 12f; setTextColor(muted); typeface = Typeface.MONOSPACE; maxLines = 1; ellipsize = android.text.TextUtils.TruncateAt.END }
        screen.addView(nowTitle, LinearLayout.LayoutParams(-1, dp(58)))
        screen.addView(nowArtist, LinearLayout.LayoutParams(-1, dp(26)))
        val wave = TextView(this).apply { text = "﹏ 〰 ﹏ 〰 ﹏ 〰 ﹏ 〰 ﹏ 〰"; gravity = Gravity.CENTER; textSize = 18f; setTextColor(accent); typeface = Typeface.MONOSPACE }
        screen.addView(wave, LinearLayout.LayoutParams(-1, dp(34)))
        val timeRow = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL; gravity = Gravity.CENTER_VERTICAL }
        elapsed = monoLabel("0:00", muted); duration = monoLabel("0:00", muted).apply { gravity = Gravity.END }
        timeRow.addView(elapsed, LinearLayout.LayoutParams(0, dp(22), 1f)); timeRow.addView(duration, LinearLayout.LayoutParams(0, dp(22), 1f)); screen.addView(timeRow)
        progress = SeekBar(this).apply {
            max = 1000; progress = 0; progressTintList = android.content.res.ColorStateList.valueOf(accent); thumbTintList = android.content.res.ColorStateList.valueOf(accent)
            progressBackgroundTintList = android.content.res.ColorStateList.valueOf(Color.rgb(67, 71, 67)); setPadding(0, 0, 0, 0)
            setOnSeekBarChangeListener(object : SeekBar.OnSeekBarChangeListener {
                override fun onStartTrackingTouch(seekBar: SeekBar?) { userSeeking = true }
                override fun onProgressChanged(seekBar: SeekBar?, value: Int, fromUser: Boolean) { if (fromUser) { val total = controller?.duration?.takeIf { it > 0L } ?: 0L; elapsed.text = formatTime(total * value / 1000) } }
                override fun onStopTrackingTouch(seekBar: SeekBar?) { val c = controller; val total = c?.duration?.takeIf { it > 0L } ?: 0L; if (c != null && total > 0L) c.seekTo(total * (seekBar?.progress ?: 0) / 1000); userSeeking = false }
            })
        }
        screen.addView(progress, LinearLayout.LayoutParams(-1, dp(26)))
        val controls = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL; gravity = Gravity.CENTER }
        shuffleButton = controlButton("⤨", 0) { shuffle = !shuffle; controller?.shuffleModeEnabled = shuffle; updateControlTints() }
        val prev = controlButton("|◀", 0) { controller?.seekToPreviousMediaItem() }
        playButton = controlButton("▶", 1) { togglePlayback() }
        val next = controlButton("▶|", 0) { controller?.seekToNextMediaItem() }
        repeatButton = controlButton("↻", 0) { repeatMode = when (repeatMode) { Player.REPEAT_MODE_OFF -> Player.REPEAT_MODE_ALL; Player.REPEAT_MODE_ALL -> Player.REPEAT_MODE_ONE; else -> Player.REPEAT_MODE_OFF }; controller?.repeatMode = repeatMode; updateControlTints() }
        listOf(shuffleButton, prev, playButton, next, repeatButton).forEachIndexed { i, button -> controls.addView(button, LinearLayout.LayoutParams(0, dp(if (i == 2) 58 else 48), if (i == 2) 1.25f else 1f)) }
        screen.addView(controls)
        return screen
    }

    private fun buildSettingsScreen(): ScrollView {
        val scroll = ScrollView(this).apply { setPadding(0, dp(12), 0, dp(12)) }
        val body = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL }
        body.addView(sectionTitle("AERO ACCENT"))
        body.addView(TextView(this).apply { text = "Choose the glow of your interface"; textSize = 12f; setTextColor(muted) }, LinearLayout.LayoutParams(-1, dp(28)))
        val colors = listOf("aqua" to "AQUA", "blue" to "SKY", "green" to "LIME", "pink" to "PINK", "purple" to "VIOLET", "white" to "PEARL")
        colors.chunked(3).forEach { group ->
            val row = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL }
            group.forEach { (key, name) ->
                val swatch = TextView(this).apply {
                    text = "●  $name"; textSize = 10f; typeface = Typeface.MONOSPACE; setTextColor(colorFor(key)); gravity = Gravity.CENTER; isClickable = true; isFocusable = true
                    setOnClickListener {
                        prefs.edit().putString("theme", key).apply()
                        accent = colorFor(key)
                        val tab = currentTab
                        buildUi()
                        loadTracks()
                        showTab(tab, false)
                        glitch.flash()
                    }
                }
                row.addView(swatch, LinearLayout.LayoutParams(0, dp(48), 1f).apply { marginEnd = dp(5) })
            }
            body.addView(row)
        }
        body.addView(separator(), LinearLayout.LayoutParams(-1, dp(1)).apply { topMargin = dp(12); bottomMargin = dp(14) })
        body.addView(sectionTitle("WALLPAPER"))
        body.addView(TextView(this).apply { text = "Bring your own sky, sea or scenery"; textSize = 12f; setTextColor(muted) }, LinearLayout.LayoutParams(-1, dp(30)))
        body.addView(settingButton("[ CHOOSE IMAGE ]") { wallpaperPicker.launch(arrayOf("image/*")) })
        body.addView(settingButton("[ RESET WALLPAPER ]") { wallpaperUri = null; prefs.edit().remove("wallpaper").apply(); applyWallpaper(); applySurfaceStyle(); glitch.flash() })
        body.addView(separator(), LinearLayout.LayoutParams(-1, dp(1)).apply { topMargin = dp(12); bottomMargin = dp(14) })
        body.addView(sectionTitle("GLASS SURFACE"))
        body.addView(TextView(this).apply { text = "Tune the transparency of the glass panels."; textSize = 12f; setTextColor(muted) }, LinearLayout.LayoutParams(-1, dp(42)))
        val modes = listOf("SOLID" to 0, "GLASS" to 1, "GHOST" to 2)
        modes.forEach { (label, value) -> body.addView(settingButton("[ $label ]" + if (surfaceMode == value) "  ✓" else "") { surfaceMode = value; prefs.edit().putInt("surface", value).apply(); applySurfaceStyle(); glitch.flash(); buildSettingsRefresh() }) }
        body.addView(separator(), LinearLayout.LayoutParams(-1, dp(1)).apply { topMargin = dp(12); bottomMargin = dp(14) })
        body.addView(sectionTitle("STARTUP EXPERIENCE"))
        body.addView(settingButton("[ STARTUP ANIMATION: ${if (splashEnabled) "ON" else "OFF"} ]") { splashEnabled = !splashEnabled; prefs.edit().putBoolean("splash", splashEnabled).apply(); buildSettingsRefresh() })
        body.addView(settingButton("[ SYSTEM CHIMES: ${if (signalsEnabled) "ON" else "OFF"} ]") { signalsEnabled = !signalsEnabled; prefs.edit().putBoolean("signals", signalsEnabled).apply(); buildSettingsRefresh() })
        body.addView(separator(), LinearLayout.LayoutParams(-1, dp(1)).apply { topMargin = dp(12); bottomMargin = dp(14) })
        body.addView(TextView(this).apply { text = "SHELTER 101 RECOMMENDS"; textSize = 10f; setTextColor(Color.argb(200, 205, 248, 255)); gravity = Gravity.CENTER; typeface = Typeface.MONOSPACE; setPadding(0, dp(18), 0, dp(18)); isClickable = true; setOnClickListener { showShelterNotice() } }, LinearLayout.LayoutParams(-1, dp(52)))
        body.addView(sectionTitle("ABOUT AERO TAPE"))
        body.addView(TextView(this).apply { text = "AERO TAPE / LOCAL MUSIC PLAYER\nYour music stays on your device."; textSize = 11f; setTextColor(muted); typeface = Typeface.MONOSPACE }, LinearLayout.LayoutParams(-1, dp(54)))
        scroll.addView(body)
        return scroll
    }

    private fun roundedGlass(fill: Int, radius: Float, stroke: Int): GradientDrawable = GradientDrawable(GradientDrawable.Orientation.TL_BR, intArrayOf(Color.argb(170, 225, 255, 255), fill, Color.argb(110, 25, 126, 163))).apply { cornerRadius = radius; setStroke(dp(1), stroke) }

    private fun showAeroSplash() {
        val overlay = FrameLayout(this).apply {
            background = GradientDrawable(GradientDrawable.Orientation.TL_BR, intArrayOf(Color.rgb(9, 37, 62), Color.rgb(24, 116, 151), Color.rgb(108, 208, 207)))
            alpha = 0f
        }
        val orb = TextView(this).apply {
            text = "◉"; gravity = Gravity.CENTER; textSize = 86f; setTextColor(Color.WHITE)
            background = GradientDrawable(GradientDrawable.Orientation.TL_BR, intArrayOf(Color.argb(220, 230, 255, 255), Color.argb(130, 69, 205, 234), Color.argb(100, 17, 106, 161))).apply { shape = GradientDrawable.OVAL; setStroke(dp(2), Color.argb(210, 255, 255, 255)) }
            elevation = dp(18).toFloat()
        }
        val center = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL; gravity = Gravity.CENTER }
        center.addView(orb, LinearLayout.LayoutParams(dp(150), dp(150)).apply { bottomMargin = dp(28) })
        center.addView(TextView(this).apply { text = "A E R O   T A P E"; textSize = 24f; gravity = Gravity.CENTER; setTextColor(Color.WHITE); typeface = Typeface.create("sans-serif-light", Typeface.NORMAL); letterSpacing = .12f }, LinearLayout.LayoutParams(-1, dp(48)))
        val message = TextView(this).apply { text = "INITIALIZING AUDIO SYSTEM"; textSize = 11f; gravity = Gravity.CENTER; setTextColor(Color.rgb(215, 255, 255)); typeface = Typeface.MONOSPACE }
        center.addView(message, LinearLayout.LayoutParams(-1, dp(36)))
        overlay.addView(center, FrameLayout.LayoutParams(-1, -1))
        root.addView(overlay, FrameLayout.LayoutParams(-1, -1))
        splashOverlay = overlay
        overlay.animate().alpha(1f).setDuration(380).start()
        if (signalsEnabled) playSoftChime(1)
        Handler(Looper.getMainLooper()).postDelayed({ message.text = "CONNECTING TO LOCAL ARCHIVE"; if (signalsEnabled) playSoftChime(2) }, 650L)
        Handler(Looper.getMainLooper()).postDelayed({ message.text = "AUDIO ARCHIVE READY  ·  WELCOME BACK" }, 1350L)
        Handler(Looper.getMainLooper()).postDelayed({
            overlay.animate().alpha(0f).setDuration(450).withEndAction { root.removeView(overlay); splashOverlay = null }.start()
        }, 2150L)
        overlay.setOnClickListener { overlay.animate().alpha(0f).setDuration(180).withEndAction { root.removeView(overlay); splashOverlay = null }.start() }
    }

    private fun playSoftChime(which: Int) {
        try { val tone = ToneGenerator(AudioManager.STREAM_MUSIC, 18); tone.startTone(if (which == 1) ToneGenerator.TONE_PROP_ACK else ToneGenerator.TONE_PROP_BEEP, 75); Handler(Looper.getMainLooper()).postDelayed({ tone.release() }, 150L) } catch (_: Exception) { }
    }

    private fun showShelterNotice() {
        android.app.AlertDialog.Builder(this).setTitle("SHELTER 101 RECOMMENDS").setMessage("Оставайся внутри. Сохраняй записи локально. Не доверяй сигналу снаружи.\n\nVAULT-TEC SYSTEM NOTICE // 101").setPositiveButton("ПРИНЯТО", null).show()
    }

    private fun buildSettingsRefresh() {
        val old = settingsScreen
        val replacement = buildSettingsScreen()
        val index = content.indexOfChild(old)
        if (index >= 0) {
            content.removeViewAt(index)
            content.addView(replacement, index, LinearLayout.LayoutParams(-1, 0, 1f))
        }
        settingsScreen = replacement
        applySurfaceStyle()
        showTab(currentTab, false)
    }

    private fun tabButton(label: String, tab: String): TextView = TextView(this).apply {
        text = label; textSize = 10f; gravity = Gravity.CENTER; typeface = Typeface.MONOSPACE; setTextColor(if (currentTab == tab) accent else muted); isClickable = true; isFocusable = true
        setOnClickListener { showTab(tab, true) }
    }

    private fun showTab(tab: String, animate: Boolean) {
        currentTab = tab
        val desktopMode = tab == "DESKTOP"
        // The first four children are the desktop chrome: title, greeting, shortcuts and glass widget.
        for (i in 0..3) content.getChildAt(i)?.visibility = if (desktopMode) View.VISIBLE else View.GONE
        content.getChildAt(4)?.visibility = if (desktopMode) View.GONE else View.VISIBLE // navigation tabs
        libraryScreen.visibility = if (tab == "LIBRARY") View.VISIBLE else View.GONE
        nowScreen.visibility = if (tab == "NOW") View.VISIBLE else View.GONE
        settingsScreen.visibility = if (tab == "SETTINGS") View.VISIBLE else View.GONE
        // Tab buttons live in child 4; keep their active state in sync.
        val tabRow = content.getChildAt(4) as? LinearLayout
        tabRow?.let { row -> for (i in 0 until row.childCount) {
            val v = row.getChildAt(i) as? TextView ?: continue
            v.setTextColor(if ((i == 0 && tab == "LIBRARY") || (i == 1 && tab == "NOW") || (i == 2 && tab == "SETTINGS")) accent else muted)
        } }
        if (animate) { glitch.flash(); if (signalsEnabled) playSoftChime(2) }
    }

    private fun loadTracks() {
        tracks.clear()
        val collection = MediaStore.Audio.Media.EXTERNAL_CONTENT_URI
        val projection = arrayOf(MediaStore.Audio.Media._ID, MediaStore.Audio.Media.TITLE, MediaStore.Audio.Media.ARTIST, MediaStore.Audio.Media.ALBUM_ID)
        try {
            contentResolver.query(collection, projection, "${MediaStore.Audio.Media.IS_MUSIC} != 0", null, "${MediaStore.Audio.Media.TITLE} COLLATE NOCASE ASC")?.use { c: Cursor ->
                val idCol = c.getColumnIndexOrThrow(MediaStore.Audio.Media._ID); val titleCol = c.getColumnIndexOrThrow(MediaStore.Audio.Media.TITLE); val artistCol = c.getColumnIndexOrThrow(MediaStore.Audio.Media.ARTIST); val albumCol = c.getColumnIndexOrThrow(MediaStore.Audio.Media.ALBUM_ID)
                while (c.moveToNext()) {
                    val id = c.getLong(idCol); val title = c.getString(titleCol)?.takeUnless { it.isBlank() || it.equals("<unknown>", true) } ?: "БЕЗ НАЗВАНИЯ"
                    val artist = c.getString(artistCol)?.takeUnless { it.isBlank() || it.equals("<unknown>", true) } ?: "НЕИЗВЕСТНЫЙ ИСПОЛНИТЕЛЬ"
                    tracks.add(Track(id, title, artist, c.getLong(albumCol), android.content.ContentUris.withAppendedId(collection, id)))
                }
            }
        } catch (_: Exception) { }
        list.removeAllViews()
        renderPlaylists()
        status.text = if (tracks.isEmpty()) "NO AUDIO FOUND · ADD MUSIC TO YOUR DEVICE" else "LOCAL ARCHIVE  ·  ${tracks.size} TRACKS"
        tracks.chunked(2).forEachIndexed { rowIndex, rowTracks ->
            val gridRow = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL; gravity = Gravity.TOP }
            rowTracks.forEachIndexed { colIndex, track ->
                val trackIndex = rowIndex * 2 + colIndex
                val card = LinearLayout(this).apply {
                    orientation = LinearLayout.VERTICAL; gravity = Gravity.CENTER; setPadding(dp(10), dp(12), dp(10), dp(12))
                    background = roundedGlass(Color.argb(118, 100, 214, 230), dp(18).toFloat(), Color.argb(150, 185, 247, 255))
                    tag = "aeroCard"
                    isClickable = true; isFocusable = true
                    setOnClickListener { playTrack(trackIndex); showTab("NOW", true) }
                    setOnLongClickListener { addTrackToPlaylist(track); true }
                }
                val orb = FrameLayout(this).apply {
                    background = GradientDrawable(GradientDrawable.Orientation.TL_BR, intArrayOf(Color.rgb(180, 250, 255), Color.rgb(58, 170, 208), Color.rgb(22, 89, 126))).apply { shape = GradientDrawable.OVAL; setStroke(dp(2), Color.argb(210, 231, 255, 255)) }
                    elevation = dp(4).toFloat()
                }
                orb.addView(TextView(this).apply {
                    text = "◉\n〰"; gravity = Gravity.CENTER; textSize = 25f; setTextColor(Color.WHITE); typeface = Typeface.create("sans-serif-light", Typeface.NORMAL)
                    setShadowLayer(dp(5).toFloat(), 0f, dp(1).toFloat(), Color.rgb(38, 118, 157))
                }, FrameLayout.LayoutParams(-1, -1))
                card.addView(orb, LinearLayout.LayoutParams(dp(100), dp(100)).apply { bottomMargin = dp(10) })
                card.addView(TextView(this).apply { text = track.title; textSize = 13f; setTextColor(Color.WHITE); gravity = Gravity.CENTER; maxLines = 2; ellipsize = android.text.TextUtils.TruncateAt.END; typeface = Typeface.create("sans-serif-medium", Typeface.NORMAL) }, LinearLayout.LayoutParams(-1, dp(38)))
                card.addView(TextView(this).apply { text = track.artist; textSize = 10f; setTextColor(muted); gravity = Gravity.CENTER; maxLines = 1; ellipsize = android.text.TextUtils.TruncateAt.END }, LinearLayout.LayoutParams(-1, dp(22)))
                card.addView(TextView(this).apply { text = "● OPEN SOUND"; textSize = 9f; setTextColor(Color.rgb(211, 255, 178)); gravity = Gravity.CENTER; typeface = Typeface.MONOSPACE }, LinearLayout.LayoutParams(-1, dp(24)))
                val lp = LinearLayout.LayoutParams(0, -2, 1f).apply { if (colIndex == 0) marginEnd = dp(8) else marginStart = dp(8); bottomMargin = dp(12) }
                gridRow.addView(card, lp)
            }
            if (rowTracks.size == 1) gridRow.addView(View(this), LinearLayout.LayoutParams(0, 1, 1f).apply { marginStart = dp(8) })
            list.addView(gridRow, LinearLayout.LayoutParams(-1, -2))
        }
        updateNowPlaying()
    }

    private fun playTrack(index: Int) {
        val c = controller ?: run { status.text = "ПЛЕЕР ЗАПУСКАЕТСЯ · ПОВТОРИ ЧЕРЕЗ СЕКУНДУ"; return }
        c.setMediaItems(tracks.map { MediaItem.fromUri(it.uri) }, index, 0L); c.prepare(); c.play(); updateNowPlaying(); glitch.flash()
    }

    private fun togglePlayback() {
        val c = controller ?: return
        if (c.isPlaying) c.pause() else { if (c.mediaItemCount == 0 && tracks.isNotEmpty()) playTrack(0) else c.play() }
        playButton.text = if (c.isPlaying) "Ⅱ" else "▶"
    }

    private fun connectController() {
        val token = SessionToken(this, ComponentName(this, PlaybackService::class.java))
        controllerFuture = MediaController.Builder(this, token).buildAsync()
        controllerFuture?.addListener({
            try {
                controller = controllerFuture?.get()
                controller?.addListener(object : Player.Listener {
                    override fun onMediaItemTransition(mediaItem: MediaItem?, reason: Int) { updateNowPlaying(); glitch.flash() }
                    override fun onIsPlayingChanged(isPlaying: Boolean) { playButton.text = if (isPlaying) "Ⅱ" else "▶" }
                    override fun onPlaybackStateChanged(playbackState: Int) { updateNowPlaying() }
                })
                updateNowPlaying()
            } catch (_: Exception) { status.text = "ОШИБКА СВЯЗИ С ПЛЕЕРОМ" }
        }, ContextCompat.getMainExecutor(this))
    }

    private fun updateNowPlaying() {
        val c = controller ?: return
        val index = c.currentMediaItemIndex
        if (index in tracks.indices) {
            val track = tracks[index]; nowTitle.text = track.title; nowArtist.text = track.artist
            var hasCover = false
            if (track.albumId > 0L) try { contentResolver.openInputStream(Uri.parse("content://media/external/audio/albumart/${track.albumId}"))?.use { cover.setImageBitmap(BitmapFactory.decodeStream(it)); hasCover = cover.drawable != null } } catch (_: Exception) { }
            if (!hasCover) cover.setImageDrawable(null)
        } else { nowTitle.text = "Choose your soundtrack"; nowArtist.text = "A little piece of your world"; cover.setImageDrawable(null) }
        playButton.text = if (c.isPlaying) "Ⅱ" else "▶"
        updateControlTints()
    }

    private fun updateControlTints() {
        shuffleButton.setTextColor(if (shuffle) accent else muted)
        repeatButton.setTextColor(if (repeatMode != Player.REPEAT_MODE_OFF) accent else muted)
        progress.progressTintList = android.content.res.ColorStateList.valueOf(accent); progress.thumbTintList = android.content.res.ColorStateList.valueOf(accent)
    }

    private fun applyWallpaper() {
        if (wallpaperUri == null) { wallpaper.setImageDrawable(null); wallpaper.visibility = View.GONE; return }
        wallpaper.visibility = View.VISIBLE
        try { wallpaper.setImageURI(wallpaperUri) } catch (_: Exception) { wallpaper.setImageDrawable(null) }
    }

    private fun applySurfaceStyle() {
        val hasWallpaper = wallpaperUri != null
        wallpaper.alpha = when (surfaceMode) { 0 -> 0.22f; 1 -> 0.52f; else -> 0.78f }
        val panelAlpha = when (surfaceMode) { 0 -> 238; 1 -> 128; else -> 28 }
        // Keep authored Aero glass drawables intact. Older code flattened every LinearLayout
        // into a dark rectangle here, which erased the glass effect on the desktop and taskbar.
        content.setBackgroundColor(Color.TRANSPARENT)
        libraryScreen.setBackgroundColor(Color.TRANSPARENT); nowScreen.setBackgroundColor(Color.TRANSPARENT); settingsScreen.setBackgroundColor(Color.TRANSPARENT)
        playerPanelStyle()
    }

    private fun playerPanelStyle() { /* The now-playing layout intentionally stays open over the wallpaper. */ }

    private fun applyThemeToViews(view: View) {
        if (view is TextView) {
            val text = view.text?.toString().orEmpty()
            if (text.contains("A E R O") || text.contains("OFFLINE") || text.contains("СЕЙЧАС В ЭФИРЕ") || text.contains("▁") || text == "VT") view.setTextColor(accent)
        }
        if (view is SeekBar) { view.progressTintList = android.content.res.ColorStateList.valueOf(accent); view.thumbTintList = android.content.res.ColorStateList.valueOf(accent) }
        if (view is ViewGroup) for (i in 0 until view.childCount) applyThemeToViews(view.getChildAt(i))
        updateControlTints()
    }

    private fun controlButton(label: String, prominent: Int, action: () -> Unit): TextView = TextView(this).apply {
        text = label; textSize = if (prominent == 1) 26f else 18f; setTextColor(accent); gravity = Gravity.CENTER; typeface = Typeface.MONOSPACE
        background = if (prominent == 1) ColorDrawable(surfaceColor()) else ColorDrawable(Color.TRANSPARENT)
        isClickable = true; isFocusable = true; setOnClickListener { action() }
    }
    private fun settingButton(label: String, action: () -> Unit) = TextView(this).apply {
        text = label; textSize = 12f; setTextColor(accent); typeface = Typeface.MONOSPACE; gravity = Gravity.CENTER_VERTICAL; setPadding(dp(12), 0, dp(12), 0); background = ColorDrawable(surfaceColor()); isClickable = true; isFocusable = true; setOnClickListener { action() }
        layoutParams = LinearLayout.LayoutParams(-1, dp(48)).apply { bottomMargin = dp(6) }
    }
    private fun sectionTitle(text: String) = TextView(this).apply { this.text = text; textSize = 13f; setTextColor(accent); typeface = Typeface.MONOSPACE; gravity = Gravity.CENTER_VERTICAL }
    private fun monoLabel(text: String, color: Int) = TextView(this).apply { this.text = text; textSize = 10f; setTextColor(color); typeface = Typeface.MONOSPACE }
    private fun separator() = View(this).apply { setBackgroundColor(Color.argb(120, Color.red(accent), Color.green(accent), Color.blue(accent))) }
    private fun surfaceColor(): Int = when (surfaceMode) { 0 -> Color.rgb(13, 47, 66); 1 -> Color.argb(190, 47, 132, 157); else -> Color.argb(65, 75, 180, 200) }
    private fun colorFor(key: String): Int = when (key) {
        "blue" -> Color.rgb(94, 171, 255); "green" -> Color.rgb(177, 255, 128); "pink" -> Color.rgb(255, 147, 220); "purple" -> Color.rgb(190, 158, 255); "white" -> Color.rgb(238, 252, 255); else -> Color.rgb(72, 226, 238)
    }
    private fun formatTime(ms: Long): String { if (ms <= 0L) return "0:00"; val s = ms / 1000; return "${s / 60}:${(s % 60).toString().padStart(2, '0')}" }
    private fun dp(value: Int) = (value * resources.displayMetrics.density).toInt()

    private inner class GlitchView : View(this@MainActivity) {
        private val paint = Paint(Paint.ANTI_ALIAS_FLAG)
        private var intensity = 0f
        private var animator: ValueAnimator? = null
        fun flash() {
            animator?.cancel()
            animator = ValueAnimator.ofFloat(0f, 1f, .15f, .8f, 0f).apply {
                duration = 420L; interpolator = LinearInterpolator()
                addUpdateListener { intensity = it.animatedValue as Float; invalidate() }; start()
            }
        }
        override fun onDraw(canvas: Canvas) {
            super.onDraw(canvas)
            // Soft glass bubbles instead of CRT scanlines.
            for (i in 0..5) {
                val x = width * ((i * 0.197f + 0.11f) % 1f)
                val y = height * ((i * 0.173f + 0.09f) % 1f)
                val r = dp(9 + (i % 3) * 5).toFloat()
                paint.shader = android.graphics.RadialGradient(x - r * .25f, y - r * .3f, r * 1.8f, intArrayOf(Color.argb(38, 255, 255, 255), Color.argb(5, 92, 236, 255), Color.TRANSPARENT), null, android.graphics.Shader.TileMode.CLAMP)
                canvas.drawCircle(x, y, r, paint); paint.shader = null
                paint.style = Paint.Style.STROKE; paint.strokeWidth = dp(1).toFloat(); paint.color = Color.argb(30, 235, 255, 255); canvas.drawCircle(x, y, r, paint); paint.style = Paint.Style.FILL
            }
            if (intensity > .05f) {
                paint.color = Color.argb((intensity * 38).toInt().coerceIn(0, 38), 210, 255, 255)
                canvas.drawRoundRect(width * .12f, height * .18f, width * .88f, height * .19f, dp(8).toFloat(), dp(8).toFloat(), paint)
            }
        }
    }

    override fun onDestroy() {
        handler.removeCallbacks(progressUpdater)
        controllerFuture?.let { MediaController.releaseFuture(it) }
        super.onDestroy()
    }
}
