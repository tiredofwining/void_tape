plugins {
    id("com.android.application")
    id("org.jetbrains.kotlin.android")
}
android {
    namespace = "com.voidtape.player"
    compileSdk = 36
    defaultConfig {
        applicationId = "com.aerotape.player"
        minSdk = 23
        targetSdk = 35
        versionCode = 5
        versionName = "0.6.0-desktop"
    }
}
dependencies {
    implementation("androidx.core:core-ktx:1.16.0")
    implementation("androidx.appcompat:appcompat:1.7.1")
    implementation("com.google.android.material:material:1.12.0")
    implementation("androidx.media3:media3-exoplayer:1.8.0")
    implementation("androidx.media3:media3-session:1.8.0")
}
