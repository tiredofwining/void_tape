# AERO TAPE — Desktop build (0.5)

A Frutiger Aero-inspired offline Android music player with a Vista-style desktop shell.

## Included in this source update
- Glassy desktop shortcut area for My Music, Aero Player, and Settings
- Local offline audio library and Media3 playback service retained
- User-created playlist folders, rename/delete, and add tracks via long-press
- Playlist data stored locally on the device; deleting a playlist does not delete audio files
- Existing wallpaper, accent, startup screen and system media controls retained
- Separate Android application ID: `com.aerotape.player`

## Build status
Source and ZIP structure prepared, but Android compilation and device testing have not been run in this environment. Build using the included GitHub Actions workflow and test the APK before relying on it.


AERO TAPE Desktop v0.6: launches into a separate desktop home screen, with My Music, Aero Player, Settings shortcuts and a persistent glass taskbar. Package ID: com.aerotape.player.
