# AERO TAPE

A Frutiger Aero-inspired offline Android music player, based on the VOID TAPE prototype.

## Design direction
- Glossy aqua glass surfaces and circular monitor-inspired track tiles
- Animated AERO TAPE startup screen with optional soft system-style chimes
- Custom wallpaper and adjustable accent colours
- Local MediaStore audio library and Android Media3 playback session
- Android system media controls retained

## Build status
This source package has been edited for the AERO TAPE redesign. It has **not yet been compiled or device-tested** in this environment. Build with the included GitHub Actions workflow and test on the target Android device before treating it as release-ready.
