# VOID TAPE — VHS Offline Android Music Player

VOID TAPE is a local music player with a worn CRT/VHS-terminal aesthetic.

## Features in v0.3
- Offline playback from the device's local audio library.
- Media3 background playback and system media controls.
- Library and Now Playing tabs.
- CRT scanlines and short glitch transitions when switching tabs or tracks.
- Six phosphor accent themes: green, blue, red, cyan, yellow, and white.
- Custom wallpaper selection from the device gallery.
- SOLID, GLASS, and GHOST interface surface modes.
- Theme, wallpaper, and surface settings persist between launches.
- Android system bars/insets are respected so the camera cutout/status bar do not cover the interface.

## Build
The GitHub Actions workflow builds a debug APK and uploads it as the `VOID_TAPE-apk` artifact.

This project archive has been updated, but the APK has not been compiled or tested locally in this environment. Run the GitHub Actions workflow to verify the build before installing it.
