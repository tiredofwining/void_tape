# VOID TAPE — VHS Offline Android Music Player

VOID TAPE is a local music player with a worn CRT/VHS-terminal aesthetic.

## Features planned/included in v0.4 source
- Offline playback from the device's local audio library.
- Media3 background playback and system media controls.
- Library and Now Playing tabs.
- CRT scanlines and short glitch transitions when switching tabs or tracks.
- Six phosphor accent themes: green, blue, red, cyan, yellow, and white.
- Custom wallpaper selection from the device gallery.
- SOLID, GLASS, and GHOST interface surface modes.
- Theme, wallpaper, and surface settings persist between launches.
- Android system bars/insets are applied after the root view attaches, to keep the status bar and navigation controls clear.
- Two-column pixel cassette library; tap to play, long-press to add a cassette to a playlist.
- Create and select local playlists.
- Choose a custom cover image for the current cassette.
- Shuffle and repeat modes (off, repeat all, repeat one).
- Optional terminal boot sequence with tap-to-skip, plus a setting to disable it.
- Optional quiet UI beeps and short acknowledgement tones.
- Hidden `Shelter 101 recommends` Easter egg in Settings.
- Custom cassette icon for the launcher.

## Build
The GitHub Actions workflow builds a debug APK and uploads it as the `VOID_TAPE-apk` artifact.

This source archive has not been compiled in this environment. Run the GitHub Actions workflow and test the resulting APK on a physical Android device before treating these features as verified.
